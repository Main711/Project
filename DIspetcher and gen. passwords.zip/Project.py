import random
import string

passwords = {}

#Генерация паролей
def generatepassword(length):

    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

#Сохранение в файл
def savepasswords():
    with open('passwords.txt', 'w') as file:
        for service, password in passwords.items():
            file.write(f'{service}:{password}\n')
    print('Пароли успешно сохранены в файле.')

#добавление паролей
def addpassword(service):
    length = int(input('Введите желаемую длину пароля: '))
    password = generatepassword(length)
    passwords[service] = password
    savepasswords()
    print(f'Пароль для сервиса {service} успешно добавлен!')

#Подгружает пароли в файл
def loadpasswords():
    try:
        with open('passwords.txt', 'r') as file:
            for line in file:
                service, password = line.strip().split(':')
                passwords[service] = password
    except FileNotFoundError:
        pass

#Получение паролей
def getpassword(service):
    if service in passwords:
        print(f'Пароль для сервиса {service}: {passwords[service]}')
    else:
        print(f'Пароль для сервиса {service} не найден!')

#Основа
def main():
    while True:
        print('Добро пожаловать в диспетчер паролей!')
        print('a. Добавить пароль')
        print('g. Получить пароль')
        print('e. Выйти')

        choice = input('Выберите действие (a,g,e): ')

        if choice == 'a':
            service = input('Введите название сервиса: ')
            addpassword(service)
        elif choice == 'g':
            service = input('Введите название сервиса: ')
            getpassword(service)
        elif choice == 'e':
            break
        else:
            print('Некорректный выбор. Попробуйте еще раз.')

if __name__ == '__main__':
    main()